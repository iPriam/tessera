/*
 * Copyright (C) 2026 Priam Chambouvet
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once
#if USE(TESSERA_VULKAN_ONLY)
#include "DMABufBufferAttributes.h"
#include "SkiaVulkanDevice.h"
WTF_IGNORE_WARNINGS_IN_THIRD_PARTY_CODE_BEGIN
#include <skia/core/SkSurface.h>
#include <skia/gpu/ganesh/GrBackendSurface.h>
WTF_IGNORE_WARNINGS_IN_THIRD_PARTY_CODE_END
namespace WebCore {
// A dedicated GPU allocation. Only its descriptor and linear layout cross IPC;
// the producing context owns the allocation until the consumer releases the buffer.
class SkiaVulkanExport {
    WTF_MAKE_NONCOPYABLE(SkiaVulkanExport);
public:
    WEBCORE_EXPORT static std::unique_ptr<SkiaVulkanExport> create(const IntSize&);
    WEBCORE_EXPORT ~SkiaVulkanExport();
    SkSurface* surface() const { return m_surface.get(); }
    WEBCORE_EXPORT DMABufBufferAttributes takeAttributes();
    WEBCORE_EXPORT void acquire(UnixFileDescriptor&& releaseFence);
    WEBCORE_EXPORT UnixFileDescriptor release();
private:
    SkiaVulkanExport() = default;
    bool initialize(const IntSize&);
    VkImage m_image { VK_NULL_HANDLE };
    VkDeviceMemory m_memory { VK_NULL_HANDLE };
    VkSemaphore m_renderingSemaphore { VK_NULL_HANDLE };
    GrBackendTexture m_texture;
    sk_sp<SkSurface> m_surface;
    DMABufBufferAttributes m_attributes;
    bool m_external { false };
};
}
#endif
