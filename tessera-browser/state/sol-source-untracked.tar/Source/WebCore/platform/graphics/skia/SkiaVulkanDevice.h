/*
 * Copyright (C) 2026 Priam Chambouvet
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

#if USE(SKIA) && USE(VULKAN)

// Before Skia's headers: they include vulkan_core.h, which must come without prototypes
// for volk to declare the entry points.
#include "VulkanVolk.h"

WTF_IGNORE_WARNINGS_IN_THIRD_PARTY_CODE_BEGIN
#include <skia/gpu/ganesh/GrDirectContext.h>
#include <skia/gpu/vk/VulkanBackendContext.h>
#include <skia/gpu/vk/VulkanExtensions.h>
#include <skia/gpu/vk/VulkanPreferredFeatures.h>
WTF_IGNORE_WARNINGS_IN_THIRD_PARTY_CODE_END

#include <vector>
#include <wtf/Noncopyable.h>
#include <wtf/TZoneMalloc.h>
#include <wtf/text/CString.h>

struct GrContextOptions;

namespace WebCore {

// The Vulkan device Skia draws with. A process has one: every thread that draws with
// Skia on the GPU makes its own GrDirectContext on it, the way each thread used to
// make its own GL context. Vulkan wants a queue used by one thread at a time, and
// Skia submits from whichever thread owns the context, so the procedures Skia gets
// for queue access take a process-wide lock first.
class SkiaVulkanDevice {
    WTF_MAKE_NONCOPYABLE(SkiaVulkanDevice);
    WTF_MAKE_TZONE_ALLOCATED(SkiaVulkanDevice);
public:
    // Created on first use. Vulkan-only builds abort if initialization fails
    // or WEBKIT_SKIA_VULKAN=0; they never select another renderer.
    WEBCORE_EXPORT static SkiaVulkanDevice* singleton();

    WEBCORE_EXPORT sk_sp<GrDirectContext> createGrContext(const GrContextOptions&) const;

    const VkPhysicalDeviceLimits& limits() const { return m_properties.limits; }
    const char* deviceName() const { return m_properties.deviceName; }

    VkInstance instance() const { return m_backendContext.fInstance; }
    VkPhysicalDevice physicalDevice() const { return m_backendContext.fPhysicalDevice; }
    VkDevice device() const { return m_backendContext.fDevice; }
    uint32_t queueFamilyIndex() const { return m_backendContext.fGraphicsQueueIndex; }

    // VK_EXT_external_memory_dma_buf with DRM format modifiers: Vulkan images whose
    // memory leaves the process as dma-buf file descriptors.
    bool supportsDMABufExport() const { return m_supportsDMABufExport; }
    bool supportsSyncFD() const { return m_supportsSyncFD; }

    PFN_vkVoidFunction deviceProcAddress(const char* name) const;

    SkiaVulkanDevice();
    ~SkiaVulkanDevice();

private:
    bool initialize();

    skgpu::VulkanBackendContext m_backendContext;
    skgpu::VulkanExtensions m_extensions;
    // Skia chains its feature structs into m_features from inside m_preferredFeatures,
    // so both live as long as the device.
    skgpu::VulkanPreferredFeatures m_preferredFeatures;
    VkPhysicalDeviceFeatures2 m_features { VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2, nullptr, { } };
    std::vector<const char*> m_instanceExtensions;
    std::vector<const char*> m_deviceExtensions;
    VkPhysicalDeviceProperties m_properties { };
    bool m_supportsDMABufExport { false };
    bool m_supportsSyncFD { false };
};

} // namespace WebCore

#endif // USE(SKIA) && USE(VULKAN)
