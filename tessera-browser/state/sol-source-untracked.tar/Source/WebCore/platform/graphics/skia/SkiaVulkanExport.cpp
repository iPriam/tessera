/*
 * Copyright (C) 2026 Priam Chambouvet
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "SkiaVulkanExport.h"
#if USE(TESSERA_VULKAN_ONLY)
#include "FontRenderOptions.h"
#include "PlatformDisplay.h"
#include <limits>
WTF_IGNORE_WARNINGS_IN_THIRD_PARTY_CODE_BEGIN
#include <skia/core/SkColorSpace.h>
#include <skia/gpu/ganesh/SkSurfaceGanesh.h>
#include <skia/gpu/ganesh/vk/GrVkBackendSurface.h>
#include <skia/gpu/ganesh/vk/GrVkTypes.h>
#include <skia/gpu/ganesh/vk/GrVkBackendSemaphore.h>
#include <skia/gpu/vk/VulkanMutableTextureState.h>
WTF_IGNORE_WARNINGS_IN_THIRD_PARTY_CODE_END
namespace WebCore {
// These entry points are device-specific: volk is only loaded at the instance level.
#define DEVICE_PROC(name) auto name = reinterpret_cast<PFN_##name>(gpu->deviceProcAddress(#name))
std::unique_ptr<SkiaVulkanExport> SkiaVulkanExport::create(const IntSize& size)
{
    std::unique_ptr<SkiaVulkanExport> result(new SkiaVulkanExport);
    if (!result->initialize(size)) {
        WTFLogAlways("Tessera Vulkan DMA-BUF render target allocation failed (%dx%d)", size.width(), size.height());
        return nullptr;
    }
    return result;
}
bool SkiaVulkanExport::initialize(const IntSize& size)
{
    auto* gpu = SkiaVulkanDevice::singleton();
    if (!gpu->supportsDMABufExport()) {
        WTFLogAlways("Tessera requires VK_KHR_external_memory_fd and VK_EXT_external_memory_dma_buf");
        return false;
    }
    if (size.isEmpty())
        return false;
    if (!gpu->supportsSyncFD()) {
        WTFLogAlways("Tessera requires VK_KHR_external_semaphore_fd for GPU frame synchronization");
        return false;
    }
    VkPhysicalDeviceExternalSemaphoreInfo semaphoreInfo { };
    semaphoreInfo.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_EXTERNAL_SEMAPHORE_INFO;
    semaphoreInfo.handleType = VK_EXTERNAL_SEMAPHORE_HANDLE_TYPE_SYNC_FD_BIT;
    VkExternalSemaphoreProperties semaphoreProperties { };
    semaphoreProperties.sType = VK_STRUCTURE_TYPE_EXTERNAL_SEMAPHORE_PROPERTIES;
    vkGetPhysicalDeviceExternalSemaphoreProperties(gpu->physicalDevice(), &semaphoreInfo, &semaphoreProperties);
    constexpr VkExternalSemaphoreFeatureFlags required = VK_EXTERNAL_SEMAPHORE_FEATURE_EXPORTABLE_BIT | VK_EXTERNAL_SEMAPHORE_FEATURE_IMPORTABLE_BIT;
    if ((semaphoreProperties.externalSemaphoreFeatures & required) != required) {
        WTFLogAlways("Tessera Vulkan device does not support importing and exporting SYNC_FD semaphores");
        return false;
    }
    DEVICE_PROC(vkCreateSemaphore);
    VkExportSemaphoreCreateInfo semaphoreExport { };
    semaphoreExport.sType = VK_STRUCTURE_TYPE_EXPORT_SEMAPHORE_CREATE_INFO;
    semaphoreExport.handleTypes = VK_EXTERNAL_SEMAPHORE_HANDLE_TYPE_SYNC_FD_BIT;
    VkSemaphoreCreateInfo semaphoreCreate { };
    semaphoreCreate.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
    semaphoreCreate.pNext = &semaphoreExport;
    if (vkCreateSemaphore(gpu->device(), &semaphoreCreate, nullptr, &m_renderingSemaphore) != VK_SUCCESS)
        return false;
    constexpr VkFormat format = VK_FORMAT_B8G8R8A8_UNORM;
    constexpr VkImageUsageFlags usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
    VkPhysicalDeviceExternalImageFormatInfo externalInfo { };
    externalInfo.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_EXTERNAL_IMAGE_FORMAT_INFO;
    externalInfo.handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT;
    VkPhysicalDeviceImageFormatInfo2 formatInfo { };
    formatInfo.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_IMAGE_FORMAT_INFO_2;
    formatInfo.pNext = &externalInfo;
    formatInfo.format = format;
    formatInfo.type = VK_IMAGE_TYPE_2D;
    formatInfo.tiling = VK_IMAGE_TILING_LINEAR;
    formatInfo.usage = usage;
    VkExternalImageFormatProperties externalProperties { };
    externalProperties.sType = VK_STRUCTURE_TYPE_EXTERNAL_IMAGE_FORMAT_PROPERTIES;
    VkImageFormatProperties2 properties { };
    properties.sType = VK_STRUCTURE_TYPE_IMAGE_FORMAT_PROPERTIES_2;
    properties.pNext = &externalProperties;
    if (vkGetPhysicalDeviceImageFormatProperties2(gpu->physicalDevice(), &formatInfo, &properties) != VK_SUCCESS
        || !(externalProperties.externalMemoryProperties.externalMemoryFeatures & VK_EXTERNAL_MEMORY_FEATURE_EXPORTABLE_BIT)
        || static_cast<uint32_t>(size.width()) > properties.imageFormatProperties.maxExtent.width
        || static_cast<uint32_t>(size.height()) > properties.imageFormatProperties.maxExtent.height)
        return false;
    DEVICE_PROC(vkCreateImage);
    DEVICE_PROC(vkGetImageMemoryRequirements);
    DEVICE_PROC(vkAllocateMemory);
    DEVICE_PROC(vkBindImageMemory);
    DEVICE_PROC(vkGetImageSubresourceLayout);
    DEVICE_PROC(vkGetMemoryFdKHR);
    if (!vkGetMemoryFdKHR)
        return false;
    VkExternalMemoryImageCreateInfo external { };
    external.sType = VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_IMAGE_CREATE_INFO;
    external.handleTypes = VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT;
    VkImageCreateInfo info { };
    info.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    info.pNext = &external;
    info.imageType = VK_IMAGE_TYPE_2D;
    info.format = format;
    info.extent = { static_cast<uint32_t>(size.width()), static_cast<uint32_t>(size.height()), 1 };
    info.mipLevels = 1;
    info.arrayLayers = 1;
    info.samples = VK_SAMPLE_COUNT_1_BIT;
    info.tiling = VK_IMAGE_TILING_LINEAR;
    info.usage = usage;
    info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    if (vkCreateImage(gpu->device(), &info, nullptr, &m_image) != VK_SUCCESS)
        return false;
    VkMemoryRequirements requirements;
    vkGetImageMemoryRequirements(gpu->device(), m_image, &requirements);
    VkPhysicalDeviceMemoryProperties memoryProperties;
    vkGetPhysicalDeviceMemoryProperties(gpu->physicalDevice(), &memoryProperties);
    auto memoryTypes = std::span(memoryProperties.memoryTypes).first(memoryProperties.memoryTypeCount);
    std::optional<uint32_t> memoryType;
    for (uint32_t i = 0; i < memoryProperties.memoryTypeCount; ++i) {
        if (!(requirements.memoryTypeBits & (1u << i)))
            continue;
        if (!memoryType || (memoryTypes[i].propertyFlags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT))
            memoryType = i;
        if (memoryTypes[i].propertyFlags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)
            break;
    }
    if (!memoryType)
        return false;
    VkMemoryDedicatedAllocateInfo dedicated { };
    dedicated.sType = VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO;
    dedicated.image = m_image;
    VkExportMemoryAllocateInfo exportInfo { };
    exportInfo.sType = VK_STRUCTURE_TYPE_EXPORT_MEMORY_ALLOCATE_INFO;
    exportInfo.pNext = &dedicated;
    exportInfo.handleTypes = VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT;
    VkMemoryAllocateInfo allocation { };
    allocation.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
    allocation.pNext = &exportInfo;
    allocation.allocationSize = requirements.size;
    allocation.memoryTypeIndex = *memoryType;
    if (vkAllocateMemory(gpu->device(), &allocation, nullptr, &m_memory) != VK_SUCCESS
        || vkBindImageMemory(gpu->device(), m_image, m_memory, 0) != VK_SUCCESS)
        return false;
    VkImageSubresource subresource { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0 };
    VkSubresourceLayout layout;
    vkGetImageSubresourceLayout(gpu->device(), m_image, &subresource, &layout);
    if (layout.offset > std::numeric_limits<uint32_t>::max() || layout.rowPitch > std::numeric_limits<uint32_t>::max())
        return false;
    VkMemoryGetFdInfoKHR fdInfo { };
    fdInfo.sType = VK_STRUCTURE_TYPE_MEMORY_GET_FD_INFO_KHR;
    fdInfo.memory = m_memory;
    fdInfo.handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT;
    int fd = -1;
    if (vkGetMemoryFdKHR(gpu->device(), &fdInfo, &fd) != VK_SUCCESS)
        return false;
    m_attributes.size = size;
    m_attributes.fourcc = 0x34325241; // DRM_FORMAT_ARGB8888: B,G,R,A bytes on a little-endian target.
    m_attributes.fds.append(UnixFileDescriptor { fd, UnixFileDescriptor::Adopt });
    m_attributes.offsets.append(static_cast<uint32_t>(layout.offset));
    m_attributes.strides.append(static_cast<uint32_t>(layout.rowPitch));
    m_attributes.modifier = 0; // DRM_FORMAT_MOD_LINEAR; no libdrm dependency.
    GrVkImageInfo imageInfo;
    imageInfo.fImage = m_image;
    imageInfo.fAlloc.fMemory = m_memory;
    imageInfo.fAlloc.fSize = requirements.size;
    imageInfo.fImageTiling = VK_IMAGE_TILING_LINEAR;
    imageInfo.fFormat = format;
    imageInfo.fImageUsageFlags = usage;
    imageInfo.fLevelCount = 1;
    imageInfo.fCurrentQueueFamily = gpu->queueFamilyIndex();
    m_texture = GrBackendTextures::MakeVk(size.width(), size.height(), imageInfo);
    auto props = FontRenderOptions::singleton().createSurfaceProps();
    m_surface = SkSurfaces::WrapBackendTexture(PlatformDisplay::sharedDisplay().skiaGrContext(), m_texture, kTopLeft_GrSurfaceOrigin, 0, kBGRA_8888_SkColorType, SkColorSpace::MakeSRGB(), &props);
    return !!m_surface;
}
DMABufBufferAttributes SkiaVulkanExport::takeAttributes() { return WTF::move(m_attributes); }
UnixFileDescriptor SkiaVulkanExport::release()
{
    auto* gpu = SkiaVulkanDevice::singleton();
    auto* context = PlatformDisplay::sharedDisplay().skiaGrContext();
    auto state = skgpu::MutableTextureStates::MakeVulkan(VK_IMAGE_LAYOUT_GENERAL, VK_QUEUE_FAMILY_EXTERNAL);
    auto semaphore = GrBackendSemaphores::MakeVk(m_renderingSemaphore);
    GrFlushInfo flushInfo;
    flushInfo.fNumSemaphores = 1;
    flushInfo.fSignalSemaphores = &semaphore;
    RELEASE_ASSERT_WITH_MESSAGE(context->flush(m_surface.get(), flushInfo, &state) == GrSemaphoresSubmitted::kYes, "Vulkan frame signal semaphore was not submitted");
    RELEASE_ASSERT_WITH_MESSAGE(context->submit(GrSyncCpu::kNo), "Vulkan frame submission failed");
    DEVICE_PROC(vkGetSemaphoreFdKHR);
    RELEASE_ASSERT(vkGetSemaphoreFdKHR);
    VkSemaphoreGetFdInfoKHR fdInfo { };
    fdInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_GET_FD_INFO_KHR;
    fdInfo.semaphore = m_renderingSemaphore;
    fdInfo.handleType = VK_EXTERNAL_SEMAPHORE_HANDLE_TYPE_SYNC_FD_BIT;
    int fd = -1;
    RELEASE_ASSERT(vkGetSemaphoreFdKHR(gpu->device(), &fdInfo, &fd) == VK_SUCCESS);
    m_external = true;
    // A successful SYNC_FD export may return -1 when the work is already complete.
    return UnixFileDescriptor { fd, UnixFileDescriptor::Adopt };
}
void SkiaVulkanExport::acquire(UnixFileDescriptor&& releaseFence)
{
    auto* context = PlatformDisplay::sharedDisplay().skiaGrContext();
    if (releaseFence) {
        auto* gpu = SkiaVulkanDevice::singleton();
        DEVICE_PROC(vkCreateSemaphore);
        DEVICE_PROC(vkImportSemaphoreFdKHR);
        RELEASE_ASSERT(vkImportSemaphoreFdKHR);
        VkSemaphoreCreateInfo info { };
        info.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
        VkSemaphore waitSemaphore = VK_NULL_HANDLE;
        RELEASE_ASSERT(vkCreateSemaphore(gpu->device(), &info, nullptr, &waitSemaphore) == VK_SUCCESS);
        VkImportSemaphoreFdInfoKHR importInfo { };
        importInfo.sType = VK_STRUCTURE_TYPE_IMPORT_SEMAPHORE_FD_INFO_KHR;
        importInfo.semaphore = waitSemaphore;
        importInfo.flags = VK_SEMAPHORE_IMPORT_TEMPORARY_BIT;
        importInfo.handleType = VK_EXTERNAL_SEMAPHORE_HANDLE_TYPE_SYNC_FD_BIT;
        importInfo.fd = releaseFence.value();
        RELEASE_ASSERT(vkImportSemaphoreFdKHR(gpu->device(), &importInfo) == VK_SUCCESS);
        static_cast<void>(releaseFence.release()); // Vulkan owns the descriptor after import.
        auto semaphore = GrBackendSemaphores::MakeVk(waitSemaphore);
        // Skia takes ownership and destroys this semaphore once the GPU wait completes.
        RELEASE_ASSERT(context->wait(1, &semaphore, true));
    }
    if (!m_external)
        return;
    auto state = skgpu::MutableTextureStates::MakeVulkan(VK_IMAGE_LAYOUT_GENERAL, SkiaVulkanDevice::singleton()->queueFamilyIndex());
    RELEASE_ASSERT(context->setBackendTextureState(m_texture, state));
    m_external = false;
}
SkiaVulkanExport::~SkiaVulkanExport()
{
    if (m_surface) {
        PlatformDisplay::sharedDisplay().skiaGrContext()->flushAndSubmit(GrSyncCpu::kYes);
        m_surface = nullptr;
    }
    auto* gpu = SkiaVulkanDevice::singleton();
    DEVICE_PROC(vkDestroyImage);
    DEVICE_PROC(vkFreeMemory);
    DEVICE_PROC(vkDestroySemaphore);
    if (m_renderingSemaphore)
        vkDestroySemaphore(gpu->device(), m_renderingSemaphore, nullptr);
    if (m_image)
        vkDestroyImage(gpu->device(), m_image, nullptr);
    if (m_memory)
        vkFreeMemory(gpu->device(), m_memory, nullptr);
}
#undef DEVICE_PROC
}
#endif
