/*
 * Copyright (C) 2026 Priam Chambouvet
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "BitmapTexture.h"
#if USE(TESSERA_VULKAN_ONLY)
#include "FontRenderOptions.h"
#include "PlatformDisplay.h"
WTF_IGNORE_WARNINGS_IN_THIRD_PARTY_CODE_BEGIN
#include <skia/core/SkColorSpace.h>
#include <skia/core/SkPixmap.h>
#include <skia/gpu/ganesh/SkSurfaceGanesh.h>
WTF_IGNORE_WARNINGS_IN_THIRD_PARTY_CODE_END
namespace WebCore {
BitmapTexture::BitmapTexture(const IntSize& size, OptionSet<Flags> flags) { reset(size, flags); }
BitmapTexture::~BitmapTexture() = default;
size_t BitmapTexture::sizeInBytes() const { return static_cast<size_t>(m_size.width()) * m_size.height() * 4; }
void BitmapTexture::reset(const IntSize& size, OptionSet<Flags> flags)
{
    auto& display = PlatformDisplay::sharedDisplay();
    RELEASE_ASSERT(display.makeSkiaContextCurrent());
    if (m_vulkanSurface && size == m_size && flags == m_flags)
        return;
    m_size = size;
    m_flags = flags;
    m_pixelFormat = flags.contains(Flags::UseBGRALayout) ? PixelFormat::BGRA8 : PixelFormat::RGBA8;
    auto info = SkImageInfo::Make(size.width(), size.height(), m_pixelFormat == PixelFormat::BGRA8 ? kBGRA_8888_SkColorType : kRGBA_8888_SkColorType,
        isOpaque() ? kOpaque_SkAlphaType : kPremul_SkAlphaType, SkColorSpace::MakeSRGB());
    auto properties = FontRenderOptions::singleton().createSurfaceProps();
    m_vulkanSurface = SkSurfaces::RenderTarget(display.skiaGrContext(), skgpu::Budgeted::kYes, info, 0, kTopLeft_GrSurfaceOrigin, &properties);
    RELEASE_ASSERT_WITH_MESSAGE(m_vulkanSurface, "Failed to allocate Vulkan bitmap texture");
}
void BitmapTexture::updateContents(const void* data, const IntRect& target, const IntPoint& source, int stride, PixelFormat format)
{
    RELEASE_ASSERT(PlatformDisplay::sharedDisplay().makeSkiaContextCurrent());
    auto colorType = format == PixelFormat::BGRA8 ? kBGRA_8888_SkColorType : kRGBA_8888_SkColorType;
    auto info = SkImageInfo::Make(target.width(), target.height(), colorType, isOpaque() ? kOpaque_SkAlphaType : kPremul_SkAlphaType, SkColorSpace::MakeSRGB());
    auto bytes = static_cast<const uint8_t*>(data);
    WTF_ALLOW_UNSAFE_BUFFER_USAGE_BEGIN
    bytes += source.y() * stride + source.x() * 4;
    WTF_ALLOW_UNSAFE_BUFFER_USAGE_END
    m_vulkanSurface->writePixels(SkPixmap(info, bytes, stride), target.x(), target.y());
}
GrBackendTexture BitmapTexture::createSkiaBackendTexture() const
{
    return SkSurfaces::GetBackendTexture(m_vulkanSurface.get(), SkSurfaces::BackendHandleAccess::kFlushRead);
}
sk_sp<SkSurface> BitmapTexture::createSkiaSurface(GrDirectContext* context, GrSurfaceOrigin origin, unsigned samples) const
{
    auto properties = FontRenderOptions::singleton().createSurfaceProps();
    return SkSurfaces::WrapBackendTexture(context, createSkiaBackendTexture(), origin, samples, m_vulkanSurface->imageInfo().colorType(), SkColorSpace::MakeSRGB(), &properties);
}
}
#endif
