/*
 * Copyright (C) 2026 Priam Chambouvet
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "SkiaVulkanDevice.h"

#if USE(SKIA) && USE(VULKAN)

#include "Logging.h"
#include "VulkanVolk.h"
#include <mutex>
#include <wtf/Lock.h>
#include <wtf/StdLibExtras.h>
#include <wtf/TZoneMallocInlines.h>
#include <wtf/Vector.h>
#include <wtf/text/StringView.h>

WTF_IGNORE_WARNINGS_IN_THIRD_PARTY_CODE_BEGIN
#include <skia/gpu/ganesh/GrContextOptions.h>
#include <skia/gpu/ganesh/vk/GrVkDirectContext.h>
#include <skia/gpu/vk/VulkanMemoryAllocatorWebKit.h>
WTF_IGNORE_WARNINGS_IN_THIRD_PARTY_CODE_END

namespace WebCore {

WTF_MAKE_TZONE_ALLOCATED_IMPL(SkiaVulkanDevice);

// Every thread drawing with Skia owns a GrDirectContext, and they all submit to the one
// queue. Vulkan leaves synchronizing queue access to the caller, so the procedures that
// touch the queue are handed to Skia wrapped in this lock.
static Lock s_queueLock;
static PFN_vkQueueSubmit s_queueSubmit;
static PFN_vkQueueSubmit2 s_queueSubmit2;
static PFN_vkQueueWaitIdle s_queueWaitIdle;
static PFN_vkQueueBindSparse s_queueBindSparse;
static PFN_vkDeviceWaitIdle s_deviceWaitIdle;

static VKAPI_ATTR VkResult VKAPI_CALL lockedQueueSubmit(VkQueue queue, uint32_t submitCount, const VkSubmitInfo* submits, VkFence fence)
{
    Locker locker { s_queueLock };
    return s_queueSubmit(queue, submitCount, submits, fence);
}

static VKAPI_ATTR VkResult VKAPI_CALL lockedQueueSubmit2(VkQueue queue, uint32_t submitCount, const VkSubmitInfo2* submits, VkFence fence)
{
    Locker locker { s_queueLock };
    return s_queueSubmit2(queue, submitCount, submits, fence);
}

static VKAPI_ATTR VkResult VKAPI_CALL lockedQueueWaitIdle(VkQueue queue)
{
    Locker locker { s_queueLock };
    return s_queueWaitIdle(queue);
}

static VKAPI_ATTR VkResult VKAPI_CALL lockedQueueBindSparse(VkQueue queue, uint32_t bindInfoCount, const VkBindSparseInfo* bindInfo, VkFence fence)
{
    Locker locker { s_queueLock };
    return s_queueBindSparse(queue, bindInfoCount, bindInfo, fence);
}

static VKAPI_ATTR VkResult VKAPI_CALL lockedDeviceWaitIdle(VkDevice device)
{
    Locker locker { s_queueLock };
    return s_deviceWaitIdle(device);
}

static PFN_vkVoidFunction lockedDeviceProcAddress(StringView name)
{
    if (name == "vkQueueSubmit"_s)
        return reinterpret_cast<PFN_vkVoidFunction>(lockedQueueSubmit);
    if (name == "vkQueueSubmit2"_s || name == "vkQueueSubmit2KHR"_s)
        return s_queueSubmit2 ? reinterpret_cast<PFN_vkVoidFunction>(lockedQueueSubmit2) : nullptr;
    if (name == "vkQueueWaitIdle"_s)
        return reinterpret_cast<PFN_vkVoidFunction>(lockedQueueWaitIdle);
    if (name == "vkQueueBindSparse"_s)
        return reinterpret_cast<PFN_vkVoidFunction>(lockedQueueBindSparse);
    if (name == "vkDeviceWaitIdle"_s)
        return reinterpret_cast<PFN_vkVoidFunction>(lockedDeviceWaitIdle);
    return nullptr;
}

static bool hasExtension(const Vector<VkExtensionProperties>& extensions, ASCIILiteral name)
{
    return extensions.containsIf([&](const auto& extension) {
        return StringView::fromLatin1(extension.extensionName) == name;
    });
}

static bool environmentFlag(const char* name, bool defaultValue)
{
    const char* value = getenv(name);
    if (!value || !*value)
        return defaultValue;
    return StringView::fromLatin1(value) != "0"_s;
}

static constexpr int deviceTypeRank(VkPhysicalDeviceType type)
{
    switch (type) {
    case VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU:
        return 4;
    case VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU:
        return 3;
    case VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU:
        return 2;
    case VK_PHYSICAL_DEVICE_TYPE_CPU:
        return 0;
    default:
        return 0;
    }
}

static_assert(!deviceTypeRank(VK_PHYSICAL_DEVICE_TYPE_CPU));

SkiaVulkanDevice* SkiaVulkanDevice::singleton()
{
    static std::once_flag onceFlag;
    static SkiaVulkanDevice* device;
    std::call_once(onceFlag, [] {
        if (!environmentFlag("WEBKIT_SKIA_VULKAN", true))
            return;

        auto newDevice = makeUnique<SkiaVulkanDevice>();
        if (newDevice->initialize())
            device = newDevice.release();
    });
#if USE(TESSERA_VULKAN_ONLY)
    RELEASE_ASSERT_WITH_MESSAGE(device, "Tessera requires hardware Vulkan; initialization failed or Vulkan was disabled");
#endif
    return device;
}

SkiaVulkanDevice::SkiaVulkanDevice() = default;

// The device lives as long as the process: GPU resources Skia still holds on any thread
// at exit are released with it by the driver.
SkiaVulkanDevice::~SkiaVulkanDevice() = default;

bool SkiaVulkanDevice::initialize()
{
    if (auto result = volkInitialize(); result != VK_SUCCESS) {
        WTFLogAlways("Skia cannot use Vulkan: no Vulkan loader (%d); Vulkan initialization failed", result);
        return false;
    }

    uint32_t loaderVersion = VK_API_VERSION_1_0;
    if (vkEnumerateInstanceVersion)
        vkEnumerateInstanceVersion(&loaderVersion);
    if (loaderVersion < VK_API_VERSION_1_1) {
        WTFLogAlways("Skia cannot use Vulkan: the loader offers Vulkan 1.0 only; Vulkan initialization failed");
        return false;
    }
    // Skia's Ganesh backend supports 1.1 through 1.4; 1.3 is what the drivers this runs on
    // (Mesa's ANV, venus) all provide.
    uint32_t apiVersion = std::min<uint32_t>(loaderVersion, VK_API_VERSION_1_3);
    m_preferredFeatures.init(apiVersion);

    uint32_t count = 0;
    vkEnumerateInstanceExtensionProperties(nullptr, &count, nullptr);
    Vector<VkExtensionProperties> instanceExtensions(count);
    vkEnumerateInstanceExtensionProperties(nullptr, &count, instanceExtensions.mutableSpan().data());
    m_preferredFeatures.addToInstanceExtensions(instanceExtensions.span().data(), instanceExtensions.size(), m_instanceExtensions);

    Vector<const char*, 1> layers;
    if (environmentFlag("WEBKIT_SKIA_VULKAN_VALIDATION", false)) {
        vkEnumerateInstanceLayerProperties(&count, nullptr);
        Vector<VkLayerProperties> availableLayers(count);
        vkEnumerateInstanceLayerProperties(&count, availableLayers.mutableSpan().data());
        bool hasValidation = availableLayers.containsIf([](const auto& layer) {
            return StringView::fromLatin1(layer.layerName) == "VK_LAYER_KHRONOS_validation"_s;
        });
        if (hasValidation)
            layers.append("VK_LAYER_KHRONOS_validation");
        else
            WTFLogAlways("WEBKIT_SKIA_VULKAN_VALIDATION is set but VK_LAYER_KHRONOS_validation is not installed");
    }

    VkApplicationInfo applicationInfo { VK_STRUCTURE_TYPE_APPLICATION_INFO, nullptr, "WebKit", 0, "WebKit", 0, apiVersion };
    VkInstanceCreateInfo instanceInfo {
        VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO, nullptr, 0, &applicationInfo,
        static_cast<uint32_t>(layers.size()), layers.span().data(),
        static_cast<uint32_t>(m_instanceExtensions.size()), m_instanceExtensions.data()
    };
    VkInstance instance = VK_NULL_HANDLE;
    if (auto result = vkCreateInstance(&instanceInfo, nullptr, &instance); result != VK_SUCCESS) {
        WTFLogAlways("Skia cannot use Vulkan: vkCreateInstance failed (%d); Vulkan initialization failed", result);
        return false;
    }
    volkLoadInstanceOnly(instance);

    vkEnumeratePhysicalDevices(instance, &count, nullptr);
    Vector<VkPhysicalDevice> physicalDevices(count);
    vkEnumeratePhysicalDevices(instance, &count, physicalDevices.mutableSpan().data());

    VkPhysicalDevice physicalDevice = VK_NULL_HANDLE;
    uint32_t queueFamilyIndex = 0;
    int bestRank = 0;
    for (auto candidate : physicalDevices) {
        VkPhysicalDeviceProperties properties;
        vkGetPhysicalDeviceProperties(candidate, &properties);
        if (properties.apiVersion < VK_API_VERSION_1_1)
            continue;

        vkGetPhysicalDeviceQueueFamilyProperties(candidate, &count, nullptr);
        Vector<VkQueueFamilyProperties> queueFamilies(count);
        vkGetPhysicalDeviceQueueFamilyProperties(candidate, &count, queueFamilies.mutableSpan().data());
        auto graphicsFamily = queueFamilies.findIf([](const auto& family) {
            return family.queueFlags & VK_QUEUE_GRAPHICS_BIT;
        });
        if (graphicsFamily == notFound)
            continue;

        // Software Vulkan devices must never be selected for Tessera rendering.
        int rank = deviceTypeRank(properties.deviceType);
        if (rank > bestRank) {
            bestRank = rank;
            physicalDevice = candidate;
            queueFamilyIndex = static_cast<uint32_t>(graphicsFamily);
            m_properties = properties;
        }
    }
    if (!physicalDevice) {
        WTFLogAlways("Skia cannot use Vulkan: no hardware device with a graphics queue; Vulkan initialization failed");
        vkDestroyInstance(instance, nullptr);
        return false;
    }
    apiVersion = std::min(apiVersion, m_properties.apiVersion);

    vkEnumerateDeviceExtensionProperties(physicalDevice, nullptr, &count, nullptr);
    Vector<VkExtensionProperties> deviceExtensions(count);
    vkEnumerateDeviceExtensionProperties(physicalDevice, nullptr, &count, deviceExtensions.mutableSpan().data());

    // What a frame or a tile needs to leave the process as a dma-buf, and what an imported
    // dma-buf needs to come back in: taken when present, never required.
    static constexpr std::array optionalExtensions {
        "VK_KHR_external_memory_fd"_s,
        "VK_EXT_external_memory_dma_buf"_s,
        "VK_KHR_image_format_list"_s,
        "VK_EXT_image_drm_format_modifier"_s,
        "VK_KHR_external_semaphore_fd"_s,
        "VK_EXT_queue_family_foreign"_s,
    };
    for (auto name : optionalExtensions) {
        if (hasExtension(deviceExtensions, name))
            m_deviceExtensions.push_back(name.characters());
    }
    m_supportsSyncFD = hasExtension(deviceExtensions, "VK_KHR_external_semaphore_fd"_s);
    m_supportsDMABufExport = hasExtension(deviceExtensions, "VK_KHR_external_memory_fd"_s)
        && hasExtension(deviceExtensions, "VK_EXT_external_memory_dma_buf"_s);

    m_preferredFeatures.addFeaturesToQuery(deviceExtensions.span().data(), deviceExtensions.size(), m_features);
    vkGetPhysicalDeviceFeatures2(physicalDevice, &m_features);
    // Bounds-checked buffer access costs every draw and protects against nothing Skia does.
    m_features.features.robustBufferAccess = VK_FALSE;
    m_preferredFeatures.addFeaturesToEnable(m_deviceExtensions, m_features);

    static constexpr float queuePriority = 1.0f;
    VkDeviceQueueCreateInfo queueInfo { VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO, nullptr, 0, queueFamilyIndex, 1, &queuePriority };
    VkDeviceCreateInfo deviceInfo {
        VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO, &m_features, 0, 1, &queueInfo, 0, nullptr,
        static_cast<uint32_t>(m_deviceExtensions.size()), m_deviceExtensions.data(), nullptr
    };
    VkDevice device = VK_NULL_HANDLE;
    if (auto result = vkCreateDevice(physicalDevice, &deviceInfo, nullptr, &device); result != VK_SUCCESS) {
        WTFLogAlways("Skia cannot use Vulkan: vkCreateDevice failed on %s (%d); Vulkan initialization failed", m_properties.deviceName, result);
        vkDestroyInstance(instance, nullptr);
        return false;
    }

    auto getDeviceQueue = reinterpret_cast<PFN_vkGetDeviceQueue>(vkGetDeviceProcAddr(device, "vkGetDeviceQueue"));
    VkQueue queue = VK_NULL_HANDLE;
    getDeviceQueue(device, queueFamilyIndex, 0, &queue);

    s_queueSubmit = reinterpret_cast<PFN_vkQueueSubmit>(vkGetDeviceProcAddr(device, "vkQueueSubmit"));
    s_queueSubmit2 = reinterpret_cast<PFN_vkQueueSubmit2>(vkGetDeviceProcAddr(device, apiVersion >= VK_API_VERSION_1_3 ? "vkQueueSubmit2" : "vkQueueSubmit2KHR"));
    s_queueWaitIdle = reinterpret_cast<PFN_vkQueueWaitIdle>(vkGetDeviceProcAddr(device, "vkQueueWaitIdle"));
    s_queueBindSparse = reinterpret_cast<PFN_vkQueueBindSparse>(vkGetDeviceProcAddr(device, "vkQueueBindSparse"));
    s_deviceWaitIdle = reinterpret_cast<PFN_vkDeviceWaitIdle>(vkGetDeviceProcAddr(device, "vkDeviceWaitIdle"));

    auto getProc = [](const char* name, VkInstance instance, VkDevice device) -> PFN_vkVoidFunction {
        if (device != VK_NULL_HANDLE) {
            if (auto locked = lockedDeviceProcAddress(StringView::fromLatin1(name)))
                return locked;
            return vkGetDeviceProcAddr(device, name);
        }
        return vkGetInstanceProcAddr(instance, name);
    };

    m_extensions.init(getProc, instance, physicalDevice,
        static_cast<uint32_t>(m_instanceExtensions.size()), m_instanceExtensions.data(),
        static_cast<uint32_t>(m_deviceExtensions.size()), m_deviceExtensions.data());

    m_backendContext.fInstance = instance;
    m_backendContext.fPhysicalDevice = physicalDevice;
    m_backendContext.fDevice = device;
    m_backendContext.fQueue = queue;
    m_backendContext.fGraphicsQueueIndex = queueFamilyIndex;
    m_backendContext.fMaxAPIVersion = apiVersion;
    m_backendContext.fVkExtensions = &m_extensions;
    m_backendContext.fDeviceFeatures2 = &m_features;
    m_backendContext.fGetProc = getProc;
    m_backendContext.fMemoryAllocator = skgpu::MakeWebKitVulkanMemoryAllocator(m_backendContext);
    if (!m_backendContext.fMemoryAllocator) {
        WTFLogAlways("Skia cannot use Vulkan: no memory allocator for %s; Vulkan initialization failed", m_properties.deviceName);
        return false;
    }

    RELEASE_LOG(Vulkan, "Skia draws with Vulkan %u.%u on %s%s", VK_API_VERSION_MAJOR(apiVersion), VK_API_VERSION_MINOR(apiVersion), m_properties.deviceName, m_supportsDMABufExport ? " (dma-buf export)" : "");
    return true;
}

sk_sp<GrDirectContext> SkiaVulkanDevice::createGrContext(const GrContextOptions& options) const
{
    return GrDirectContexts::MakeVulkan(m_backendContext, options);
}

PFN_vkVoidFunction SkiaVulkanDevice::deviceProcAddress(const char* name) const
{
    if (auto locked = lockedDeviceProcAddress(StringView::fromLatin1(name)))
        return locked;
    return vkGetDeviceProcAddr(m_backendContext.fDevice, name);
}

} // namespace WebCore

#endif // USE(SKIA) && USE(VULKAN)
